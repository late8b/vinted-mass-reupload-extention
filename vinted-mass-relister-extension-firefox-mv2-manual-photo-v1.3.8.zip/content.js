// content.js
(() => {
    'use strict';

    const LOG = '[VINTED-RELIST]';
    const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));
    const storage = chrome.storage.local;

    console.log(`${LOG} v1.3.8 content script loaded`, location.href);

    // Guard against the content script running more than once in the same page
    // (e.g. bfcache restore or double injection), which could double-fire the
    // flow and confuse Vinted's React state.
    if (window.__VINTED_RELIST_LOADED__) {
        console.warn(`${LOG} duplicate instance ignored on`, location.href);
        return;
    }
    window.__VINTED_RELIST_LOADED__ = true;

    // ---------------------------------------------------------------------
    // Route-aware lifecycle (v1.3.7)
    // Vinted is a Next.js SPA: the content script is injected once, but the URL
    // changes client-side. Without teardown, observers/timers/async stages from
    // a previous route keep running and can mutate or redirect the wrong page
    // (this is the likely cause of the profile-skeleton "something went wrong"
    // seen shortly after the form was populated). Every route change bumps
    // `generation`, aborts the previous AbortController, runs all registered
    // teardowns, then starts exactly one handler for the new route. Async work
    // carries its `gen`; `isCurrent(gen)` short-circuits stale callbacks so they
    // can never touch a newer route or trigger a redirect after navigation.
    // ---------------------------------------------------------------------
    let generation = 0;
    let currentPath = null;
    let phase = 'idle';                 // 'idle' | 'active' | 'navigating'
    let teardowns = [];
    let abortController = null;
    let autofillState = null;           // shared with the status panel controls

    const isCurrent = (gen) => gen === generation;

    function registerTeardown(fn) { teardowns.push(fn); }

    function managedInterval(gen, fn, ms) {
        const id = setInterval(() => {
            if (!isCurrent(gen)) { clearInterval(id); console.debug(`${LOG} [ROUTE] stale interval ignored (gen ${gen} != ${generation})`); return; }
            fn();
        }, ms);
        registerTeardown(() => clearInterval(id));
        return id;
    }

    function managedObserver(gen, target, options, callback) {
        const observer = new MutationObserver((mutations) => {
            if (!isCurrent(gen)) { observer.disconnect(); return; }
            callback(mutations);
        });
        observer.observe(target, options);
        registerTeardown(() => observer.disconnect());
        return observer;
    }

    function teardownRoute(reason) {
        const count = teardowns.length;
        for (const fn of teardowns.splice(0)) { try { fn(); } catch (_) {} }
        if (abortController) { try { abortController.abort(); } catch (_) {} abortController = null; }
        autofillState = null;
        for (const id of ['relist-panel', 'relist-btn']) document.getElementById(id)?.remove();
        console.log(`${LOG} [ROUTE] teardown (${reason}) disconnected=${count}`);
    }

    function onRouteChange(nextPath) {
        if (nextPath === currentPath) return;
        const previous = currentPath;
        if (previous !== null) teardownRoute('route-change');
        generation += 1;
        currentPath = nextPath;
        phase = 'active';
        abortController = new AbortController();
        console.log(`${LOG} [ROUTE] ${previous} -> ${nextPath} generation=${generation}`);
        dispatchRoute(generation);
    }

    function installRouteMonitor() {
        const emit = () => onRouteChange(location.pathname);
        for (const name of ['pushState', 'replaceState']) {
            const original = history[name];
            if (typeof original !== 'function' || original.__vintedWrapped) continue;
            const wrapped = function (...args) {
                const result = original.apply(this, args);
                queueMicrotask(emit);
                return result;
            };
            wrapped.__vintedWrapped = true;
            history[name] = wrapped;
        }
        window.addEventListener('popstate', emit);
        window.addEventListener('hashchange', emit);
        // Catch any navigation we did not intercept (<=1s latency).
        setInterval(emit, 1000);
    }

    function dispatchRoute(gen) {
        const path = location.pathname;
        const onFormPage = /\/items\/(new|\d+\/edit)\/?$/.test(path);
        // The relist launcher only belongs on browsable pages; keep it off the
        // form pages to avoid DOM churn during Vinted's React reconciliation.
        if (!onFormPage) {
            let scheduled = false;
            const debouncedInject = () => {
                if (scheduled) return;
                scheduled = true;
                requestAnimationFrame(() => { scheduled = false; injectButton(); });
            };
            managedObserver(gen, document.body || document.documentElement, { childList: true, subtree: true }, debouncedInject);
            injectButton();
        }
        processItemPage(gen).catch(error => console.error(`${LOG} [FATAL]`, error?.message, '\n', error?.stack || error));
    }

    // v1.3.8: synthetic image injection into Vinted's photo upload field has been
    // removed entirely. Feeding a synthetic file list to that field drove Vinted's
    // async upload pipeline into its "something went wrong" error boundary, which
    // then bounced the SPA back to the source page and re-triggered the flow.
    // Photos are now preserved to local Downloads and the user selects them
    // manually via Vinted's own photo picker. No synthetic-upload code remains.

    // Wrap a flow stage so a throw is logged with a stack and downgraded to a
    // recorded failure instead of bubbling into Vinted's error boundary.
    async function runStage(name, fn) {
        try {
            return { ok: true, value: await fn() };
        } catch (error) {
            console.error(`${LOG} [NEW] stage "${name}" threw:`, error?.message, '\n', error?.stack || error);
            return { ok: false, error };
        }
    }

    function getItemId() {
        return location.pathname.match(/\/items\/(\d+)/)?.[1] || null;
    }

    function getRelistId() {
        return new URLSearchParams(location.hash.replace(/^#/, '')).get('relist');
    }

    function itemBaseUrl(itemId) {
        return `${location.origin}/items/${itemId}`;
    }

    function editUrl(itemId) {
        return `${itemBaseUrl(itemId)}/edit`;
    }

    function newItemUrl(itemId) {
        return `${location.origin}/items/new#relist=${itemId}`;
    }

    function visible(el) {
        if (!el) return false;
        const style = getComputedStyle(el);
        return style.visibility !== 'hidden' && style.display !== 'none' && el.getClientRects().length > 0;
    }

    function normaliseText(value) {
        return String(value || '').replace(/\s+/g, ' ').trim();
    }

    function normaliseCompare(value) {
        return normaliseText(value).toLocaleLowerCase().replace(/[’']/g, "'");
    }

    async function storageGet(keys) {
        return new Promise((resolve, reject) => {
            storage.get(keys, result => {
                const err = chrome.runtime.lastError;
                if (err) reject(new Error(err.message)); else resolve(result || {});
            });
        });
    }

    async function storageSet(value) {
        return new Promise((resolve, reject) => {
            storage.set(value, () => {
                const err = chrome.runtime.lastError;
                if (err) reject(new Error(err.message)); else resolve();
            });
        });
    }

    async function storageRemove(keys) {
        return new Promise((resolve, reject) => {
            storage.remove(keys, () => {
                const err = chrome.runtime.lastError;
                if (err) reject(new Error(err.message)); else resolve();
            });
        });
    }

    // ---------------------------------------------------------------------
    // One-run transaction lock (v1.3.8)
    // A relist run is an irreversible, multi-page transaction (scrape -> preserve
    // images -> DELETE source -> /items/new). The video loop showed the item
    // handler re-running the whole destructive flow whenever pendingUpload data
    // existed or Vinted redirected back — re-downloading and re-attempting the
    // delete. To make the flow strictly one-shot and idempotent, every run is
    // tracked by a transaction keyed on the SOURCE item id. Rules:
    //   * A run only STARTS from an explicit user click ("Start Selected"), which
    //     writes transaction_<id> with stage 'started'. Route handlers NEVER
    //     auto-start merely because pendingUpload data exists or because Vinted
    //     redirected back — no active transaction means no download/delete/nav.
    //   * Before the irreversible delete we persist deletionAttempted=true; once
    //     that (or reachedNewPage) is set, revisiting item/edit/profile shows only
    //     a paused panel and performs NO download, NO delete, NO redirect.
    //   * A stale run (older than TTL) is recoverable manually but NEVER
    //     auto-deleted.
    // ---------------------------------------------------------------------
    const TRANSACTION_TTL_MS = 30 * 60 * 1000; // 30 minutes

    const transactionKey = (id) => `transaction_${id}`;

    function makeRunId() {
        return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
    }

    async function getTransaction(id) {
        if (!id) return null;
        const key = transactionKey(id);
        return (await storageGet([key]))[key] || null;
    }

    // Merge-patch a transaction. Reads the current record first so concurrent
    // stage updates never clobber earlier flags (deletionAttempted etc.).
    async function setTransaction(id, patch) {
        const key = transactionKey(id);
        const current = (await storageGet([key]))[key] || {};
        const next = { ...current, ...patch, updatedAt: Date.now() };
        await storageSet({ [key]: next });
        return next;
    }

    async function clearTransaction(id) {
        if (!id) return;
        await storageRemove([transactionKey(id)]);
    }

    function isStaleTransaction(tx) {
        return Boolean(tx && Date.now() - (tx.startedAt || 0) > TRANSACTION_TTL_MS);
    }

    // A run is "settled" once it has passed the point of no return (delete
    // attempted) or already reached /items/new, or has been marked failed. A
    // settled run must never re-run the destructive flow.
    function transactionSettled(tx) {
        return Boolean(tx && (tx.deletionAttempted || tx.reachedNewPage || tx.failed));
    }

    // Ask the persistent background page to download every image URL into
    // Downloads/Vinted Relist/<folder>/NN.ext and wait for each to complete.
    // Resolves with the background's structured result {ok, savedCount, total,
    // folder, results} or a synthetic failure if messaging itself fails. This is
    // the ONLY image-preservation path; the deletion gate depends on ok===true.
    async function preserveImages(urls, folder) {
        return new Promise(resolve => {
            let done = false;
            const finish = (res) => { if (!done) { done = true; resolve(res); } };
            // Downloads can legitimately take a while; give the round-trip a
            // generous ceiling so a slow-but-succeeding batch is not misreported.
            const timer = setTimeout(() => finish({ ok: false, savedCount: 0, total: urls.length, error: 'background did not respond in time' }), 180000);
            try {
                chrome.runtime.sendMessage({ action: 'DOWNLOAD_IMAGES', urls, folder }, response => {
                    clearTimeout(timer);
                    const err = chrome.runtime.lastError;
                    if (err) { finish({ ok: false, savedCount: 0, total: urls.length, error: err.message }); return; }
                    if (!response) { finish({ ok: false, savedCount: 0, total: urls.length, error: 'no response from background' }); return; }
                    finish(response);
                });
            } catch (error) {
                clearTimeout(timer);
                finish({ ok: false, savedCount: 0, total: urls.length, error: error.message });
            }
        });
    }

    // Fixed, high-z-index banner outside Vinted's React root, used on the ITEM
    // page to make image-preservation progress/errors visible to the user (the
    // console is not enough when a delete is being gated on downloads).
    function showItemBanner(message, isError = false) {
        try {
            let bar = document.getElementById('relist-item-banner');
            if (!bar) {
                bar = document.createElement('div');
                bar.id = 'relist-item-banner';
                bar.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:2147483647;padding:12px 16px;font:14px/1.4 sans-serif;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,.35)';
                (document.body || document.documentElement).appendChild(bar);
            }
            bar.textContent = `Vinted Relister: ${message}`;
            bar.style.background = isError ? '#7a1f1f' : '#0a6b45';
            bar.style.color = '#fff';
        } catch (_) { /* banner is best-effort */ }
    }

    // Compact panel shown on the SOURCE item/edit page when a run has already
    // passed the point of no return (delete attempted / reached /items/new) or
    // failed, or is stale. It performs NO download/delete/redirect on its own; it
    // only offers the user "Resume manually" (a user-click navigation, never
    // automatic) and "Clear run".
    function renderPausedPanel(id, tx, message) {
        if (!document.body || document.getElementById('relist-paused-panel')) return;
        const panel = document.createElement('div');
        panel.id = 'relist-paused-panel';
        panel.style.cssText = 'position:fixed;top:12px;right:12px;z-index:2147483647;width:320px;padding:14px;background:#1b1b1b;color:#fff;border:1px solid #7a5b1f;border-radius:8px;font:13px/1.45 sans-serif;box-shadow:0 6px 18px rgba(0,0,0,.45)';

        const h = document.createElement('div');
        h.textContent = 'Vinted Mass Relister — run paused';
        h.style.cssText = 'font-weight:bold;font-size:14px;margin-bottom:6px';

        const info = document.createElement('div');
        info.style.cssText = 'margin-bottom:10px;opacity:.9;white-space:pre-wrap';
        info.textContent = message;

        const mkBtn = (label, bg) => {
            const b = document.createElement('button');
            b.textContent = label;
            b.style.cssText = `flex:1 1 45%;margin:4px;padding:10px;background:${bg};color:#fff;border:0;border-radius:5px;font-weight:bold;cursor:pointer`;
            return b;
        };
        const row = document.createElement('div');
        row.style.cssText = 'display:flex;flex-wrap:wrap';
        const resumeBtn = mkBtn('Resume manually', '#0a8f97');
        const clearBtn = mkBtn('Clear run', '#7a2b2b');
        row.append(resumeBtn, clearBtn);

        // Resume is a USER action only. If the run already reached /items/new we
        // send the user there to finish autofill + manual photo selection; the
        // source has already been deleted and its data is preserved. We never
        // re-enter the destructive item flow from here.
        resumeBtn.onclick = () => {
            console.log(`${LOG} [TX] user resume for ${id} (reachedNewPage=${Boolean(tx?.reachedNewPage)})`);
            if (tx?.reachedNewPage) location.assign(newItemUrl(id));
            else panel.remove();
        };
        clearBtn.onclick = async () => {
            console.log(`${LOG} [TX] user cleared run for ${id}`);
            await storageRemove([transactionKey(id), `pendingUpload_${id}`, `pendingUpload_partial_${id}`, `imagesSaved_${id}`]);
            info.textContent = 'Run cleared for this item.';
            row.remove();
        };

        panel.append(h, info, row);
        document.body.appendChild(panel);
        console.log(`${LOG} [TX] paused panel shown for ${id}: ${message}`);
    }

    async function waitForAny(selectors, timeoutMs = 15000, requireValue = false) {
        const end = Date.now() + timeoutMs;
        while (Date.now() < end) {
            for (const selector of selectors) {
                const el = document.querySelector(selector);
                if (el && (!requireValue || normaliseText(el.value || el.textContent))) return el;
            }
            await sleep(250);
        }
        return selectors.map(s => document.querySelector(s)).find(Boolean) || null;
    }

    async function waitForFormToLoad() {
        const title = await waitForAny([
            'input[data-testid="title--input"]',
            'input[name="title"]',
            'input[id*="title"]'
        ], 30000, true);
        console.log(`${LOG} [EDIT] hydration`, Boolean(title), title?.value || '');
        return Boolean(title);
    }

    async function waitForNewFormToRender() {
        return Boolean(await waitForAny([
            'input[data-testid="title--input"]',
            'input[name="title"]',
            'textarea[data-testid="description--input"]'
        ], 20000));
    }

    // Let the SPA finish its initial render/hydration before we touch inputs, so
    // synthetic events do not race React's mount and trip its error boundary.
    async function waitForAppReady() {
        if (document.readyState !== 'complete') {
            await new Promise(resolve => window.addEventListener('load', resolve, { once: true }));
        }
        await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
        await sleep(400);
    }

    // Record the first appearance of a "something went wrong" screen so failures
    // are diagnosable from the console. Purely diagnostic: it NEVER redirects.
    // Bound to the route generation so it is torn down on any route change and a
    // stale timer can never log against a newer page.
    function watchPageHealth(gen) {
        let errorLogged = false;
        managedInterval(gen, () => {
            const err = pageErrorText();
            if (!errorLogged && /something went wrong|sorry.*went wrong/i.test(err)) {
                errorLogged = true;
                console.error(`${LOG} [NEW] Vinted error boundary detected on page:`, err);
            }
        }, 1000);
    }

    // Fixed status panel (outside Vinted's React root) showing staged-autofill
    // progress with Safe stop / Resume / Retry / Clear controls. Autofill runs
    // automatically once the app is ready, but every mutating action is bound to
    // the route `gen`; a route change tears the panel down and stale stages abort.
    // Nothing here publishes — it stops at the reviewable populated state.
    function renderAutofillPanel(gen, relistId, saved, fullKey, photoInfo = null) {
        if (!document.body || document.getElementById('relist-panel')) return null;
        const panel = document.createElement('div');
        panel.id = 'relist-panel';
        panel.style.cssText = 'position:fixed;top:12px;right:12px;z-index:2147483647;width:340px;padding:14px;background:#111;color:#fff;border-radius:8px;font:13px/1.45 sans-serif;box-shadow:0 6px 18px rgba(0,0,0,.45)';

        const h = document.createElement('div');
        h.textContent = 'Vinted Mass Relister — autofill';
        h.style.cssText = 'font-weight:bold;font-size:14px;margin-bottom:6px';

        const info = document.createElement('div');
        info.style.cssText = 'margin-bottom:8px;opacity:.85';
        info.textContent = `"${normaliseText(saved.title)}" · £${cleanPrice(saved.price)} · ${saved.images?.length || 0} photo(s). Text details are filled automatically. Nothing is published automatically.`;

        // v1.3.8: photos are NOT auto-uploaded. Tell the user exactly where the
        // backups are so they can pick them with Vinted's own photo picker.
        const photos = document.createElement('div');
        photos.style.cssText = 'margin-bottom:8px;padding:8px;background:#08351f;border:1px solid #0a6b45;border-radius:5px';
        const folderName = photoInfo?.folder || `${relistId} ${normaliseText(saved.title)}`;
        const count = photoInfo?.count ?? (saved.images?.length || 0);
        photos.textContent = `📷 ${count} photo(s) saved to Downloads/Vinted Relist/${folderName}. Select them manually using Vinted's photo picker (the extension does not upload photos).`;

        const status = document.createElement('div');
        status.id = 'relist-status';
        status.style.cssText = 'min-height:36px;margin:8px 0;padding:6px 8px;background:#000;border-radius:5px;white-space:pre-wrap';
        status.textContent = 'Preparing…';

        const setStatus = (message, isError = false) => {
            status.textContent = message;
            status.style.color = isError ? '#ff8f8f' : '#fff';
        };

        const mkBtn = (label, bg) => {
            const b = document.createElement('button');
            b.textContent = label;
            b.style.cssText = `flex:1 1 45%;margin:4px;padding:10px;background:${bg};color:#fff;border:0;border-radius:5px;font-weight:bold;cursor:pointer`;
            return b;
        };
        const row = document.createElement('div');
        row.style.cssText = 'display:flex;flex-wrap:wrap;margin-top:6px';
        const stopBtn = mkBtn('Safe stop', '#7a2b2b');
        const resumeBtn = mkBtn('Resume', '#09b1ba');
        const retryBtn = mkBtn('Retry', '#0a8f97');
        const clearBtn = mkBtn('Clear data', '#444');
        row.append(stopBtn, resumeBtn, retryBtn, clearBtn);

        stopBtn.onclick = () => {
            if (!autofillState || !isCurrent(gen)) return;
            autofillState.stopRequested = true;
            console.log(`${LOG} [NEW] Safe stop requested`);
            setStatus('Safe stop requested — halting after the current step. Data kept.', true);
        };
        resumeBtn.onclick = () => {
            if (!autofillState || !isCurrent(gen) || autofillState.running) return;
            console.log(`${LOG} [NEW] Resume autofill from stage ${autofillState.stageIndex}`);
            runAutofill(gen, autofillState.stageIndex);
        };
        retryBtn.onclick = () => {
            if (!autofillState || !isCurrent(gen) || autofillState.running) return;
            console.log(`${LOG} [NEW] Retry autofill from stage 0`);
            runAutofill(gen, 0);
        };
        clearBtn.onclick = async () => {
            console.log(`${LOG} [NEW] clear-data relist=${relistId}`);
            await storageRemove([fullKey, `imagesSaved_${relistId}`, transactionKey(relistId)]);
            setStatus('Saved relist data cleared for this item.');
        };

        panel.append(h, info, photos, status, row);
        document.body.appendChild(panel);
        console.log(`${LOG} [NEW] autofill panel rendered for relist=${relistId} gen=${gen}`);
        return { setStatus, buttons: { stopBtn, resumeBtn, retryBtn } };
    }

    // Ordered autofill stages. Each resolves true only on FULL success so the
    // panel can Resume from the first incomplete stage. v1.3.8: the 'images'
    // stage is removed — photos are NEVER injected into the file input. Only the
    // text fields + dropdowns + package size are filled; the user picks the
    // locally-saved photos manually. No stage clicks Vinted's Upload/List button.
    const AUTOFILL_STAGES = [
        { name: 'details', run: async (saved, onStatus) => {
            const result = await fillDetails(saved, onStatus);
            return Boolean(result && result.coreOkay);
        } }
    ];

    function updateAutofillButtons() {
        const state = autofillState;
        if (!state || !state.buttons) return;
        const { stopBtn, resumeBtn, retryBtn } = state.buttons;
        const running = state.running;
        stopBtn.disabled = !running;
        retryBtn.disabled = running;
        resumeBtn.disabled = running || state.stageIndex <= 0 || state.stageIndex >= AUTOFILL_STAGES.length;
        for (const b of [stopBtn, resumeBtn, retryBtn]) b.style.opacity = b.disabled ? '.5' : '1';
    }

    async function runAutofill(gen, fromIndex) {
        const state = autofillState;
        if (!state || !isCurrent(gen)) return;
        state.running = true;
        state.stopRequested = false;
        updateAutofillButtons();
        for (let i = fromIndex; i < AUTOFILL_STAGES.length; i++) {
            if (state.stopRequested) {
                state.stageIndex = i;
                state.setStatus('Safe-stopped. Data kept. Click Resume to continue.', true);
                state.running = false;
                updateAutofillButtons();
                return;
            }
            if (!isCurrent(gen)) { console.warn(`${LOG} [ROUTE] stale callback ignored: autofill stage aborted (gen ${gen} != ${generation})`); return; }
            const stage = AUTOFILL_STAGES[i];
            state.stageIndex = i;
            console.log(`${LOG} [NEW] stage ${i + 1}/${AUTOFILL_STAGES.length} "${stage.name}" starting`);
            state.setStatus(`Stage ${i + 1}/${AUTOFILL_STAGES.length}: ${stage.name}…`);
            const result = await runStage(stage.name, () => stage.run(state.saved, state.setStatus));
            if (!isCurrent(gen)) { console.warn(`${LOG} [ROUTE] stale callback ignored: autofill result after route change (gen ${gen} != ${generation})`); return; }
            const ok = result.ok && result.value === true;
            console.log(`${LOG} [NEW] stage "${stage.name}" success=${ok}`);
            if (state.stopRequested) {
                state.stageIndex = i;
                state.setStatus('Safe-stopped mid-stage. Data kept. Click Resume to re-run this stage.', true);
                state.running = false;
                updateAutofillButtons();
                return;
            }
            if (!ok) {
                state.setStatus(`Stage "${stage.name}" did not fully complete. Data kept. Use Retry or Resume.`, true);
                state.running = false;
                updateAutofillButtons();
                return;
            }
        }
        state.stageIndex = AUTOFILL_STAGES.length;
        state.running = false;
        updateAutofillButtons();
        state.setStatus("Details filled. Now select the saved photos manually via Vinted's photo picker, review everything, then click Vinted's Upload button yourself. Nothing was auto-published and no photos were auto-uploaded.");
        console.log(`${LOG} [NEW] autofill complete (reviewable state; no auto-publish, no photo upload)`);
    }

    function firstValue(selectors) {
        for (const selector of selectors) {
            const el = document.querySelector(selector);
            if (!el) continue;
            const candidates = [
                el.value,
                el.getAttribute('value'),
                el.getAttribute('aria-label'),
                el.getAttribute('data-value'),
                el.getAttribute('title')
            ];
            for (const candidate of candidates) {
                const value = normaliseText(candidate);
                if (value && !/select|choose|search/i.test(value)) return value;
            }
        }
        return '';
    }

    function controlDisplayValue(testId, extraSelectors = []) {
        const selectors = [
            `input[data-testid="${testId}"]`,
            `[data-testid="${testId}"]`,
            ...extraSelectors
        ];
        const direct = firstValue(selectors);
        if (direct) return direct;

        for (const selector of selectors) {
            const el = document.querySelector(selector);
            if (!el) continue;
            const root = el.closest('[data-testid$="--cell"], [role="button"], label, fieldset, div') || el.parentElement;
            if (!root) continue;
            const textCandidates = Array.from(root.querySelectorAll(
                '[data-testid*="selected"], [data-testid*="value"], .web_ui__Text__title, .web_ui__Text__subtitle, span, p'
            )).filter(visible).map(node => normaliseText(node.textContent));
            const ignored = new Set(['category', 'brand', 'size', 'condition', 'colour', 'color', 'select', 'choose']);
            const value = textCandidates.find(text => text && text.length < 120 && !ignored.has(text.toLowerCase()) && !/select|choose an? /i.test(text));
            if (value) return value;
        }
        return '';
    }

    function extractProductJsonLd() {
        const products = [];
        for (const script of document.querySelectorAll('script[type="application/ld+json"]')) {
            try {
                const parsed = JSON.parse(script.textContent || 'null');
                const nodes = Array.isArray(parsed) ? parsed : [parsed];
                for (const node of nodes) {
                    if (!node) continue;
                    if (Array.isArray(node['@graph'])) nodes.push(...node['@graph']);
                    const types = Array.isArray(node['@type']) ? node['@type'] : [node['@type']];
                    if (types.includes('Product')) products.push(node);
                }
            } catch (error) {
                console.debug(`${LOG} invalid JSON-LD ignored`, error);
            }
        }
        return products[0] || null;
    }

    function extractPageMetadata() {
        const data = { title: '', description: '', price: '', category: '', brand: '', size: '', condition: '', color: '', packageSize: '', images: [] };
        const product = extractProductJsonLd();
        if (product) {
            data.title = normaliseText(product.name);
            data.description = normaliseText(product.description);
            const offer = Array.isArray(product.offers) ? product.offers[0] : product.offers;
            data.price = normaliseText(offer?.price ?? offer?.lowPrice ?? offer?.highPrice);
            data.brand = normaliseText(typeof product.brand === 'string' ? product.brand : product.brand?.name);
            const images = Array.isArray(product.image) ? product.image : [product.image];
            data.images = images.filter(x => typeof x === 'string' && /^https?:/i.test(x));
        }
        data.title ||= normaliseText(document.querySelector('meta[property="og:title"]')?.content);
        data.description ||= normaliseText(document.querySelector('meta[property="og:description"]')?.content);
        data.price ||= normaliseText(document.querySelector('meta[property="product:price:amount"]')?.content);
        const ogImage = document.querySelector('meta[property="og:image"]')?.content;
        if (!data.images.length && ogImage) data.images = [ogImage];
        return data;
    }

    // Parse a srcset ("url 320w, url2 640w" or "url 1x, url2 2x") and return the
    // highest-resolution candidate. Vinted serves several sizes; the backup must
    // keep the largest so relisted photos are not degraded (issue C).
    function bestFromSrcset(srcset) {
        if (!srcset) return '';
        let best = '';
        let bestScore = -1;
        for (const part of srcset.split(',')) {
            const [url, descriptor] = normaliseText(part).split(/\s+/);
            if (!url || !/^https?:/i.test(url)) continue;
            let score = 1;
            if (descriptor) {
                const w = descriptor.match(/^(\d+(?:\.\d+)?)w$/);
                const x = descriptor.match(/^(\d+(?:\.\d+)?)x$/);
                if (w) score = parseFloat(w[1]);
                else if (x) score = parseFloat(x[1]) * 1000; // density: prefer over any width
            }
            if (score > bestScore) { bestScore = score; best = url; }
        }
        return best;
    }

    function scrapeImages() {
        const urls = new Set();
        const selectors = [
            'img[data-testid*="image"]',
            '[data-testid*="photo"] img',
            'img[src*="vinted"]'
        ];
        for (const img of document.querySelectorAll(selectors.join(','))) {
            // Prefer the highest-resolution candidate advertised by the element
            // (srcset on the <img> or a sibling <source>), then fall back to the
            // rendered src.
            let best = bestFromSrcset(img.getAttribute('srcset'));
            const picture = img.closest('picture');
            if (picture) {
                for (const source of picture.querySelectorAll('source')) {
                    const candidate = bestFromSrcset(source.getAttribute('srcset'));
                    if (candidate) best ||= candidate;
                }
            }
            const src = best || img.currentSrc || img.src;
            if (!src || !/^https?:/i.test(src)) continue;
            if (/avatar|icon|logo|badge/i.test(src)) continue;
            const width = img.naturalWidth || img.width;
            const height = img.naturalHeight || img.height;
            if (width && height && (width < 150 || height < 150)) continue;
            urls.add(src);
        }
        return [...urls];
    }

    function checkedPackageSize() {
        const checked = document.querySelector('input[type="radio"]:checked');
        if (!checked) return '';
        const root = checked.closest('[data-testid$="-package-size--cell"], div[id^="package-size-"], label') || checked.parentElement;
        return normaliseText(root?.querySelector('.web_ui__Text__title, [data-testid*="title"]')?.textContent || root?.textContent);
    }

    async function scrapeItemDetails() {
        const details = {
            title: firstValue(['input[data-testid="title--input"]', 'input[name="title"]']),
            description: firstValue(['textarea[data-testid="description--input"]', 'textarea[name="description"]']),
            price: firstValue(['input[data-testid="price-input--input"]', 'input[name="price"]']),
            category: controlDisplayValue('catalog-select-dropdown-input', ['[data-testid*="catalog-select"]']),
            brand: controlDisplayValue('brand-select-dropdown-input', ['[data-testid*="brand-select"]']),
            size: controlDisplayValue('category-size-single-grid-input', ['[data-testid*="size-single"]', '[data-testid*="size-select"]']),
            condition: controlDisplayValue('category-condition-single-list-input', ['[data-testid*="condition-single"]', '[data-testid*="condition-select"]']),
            color: controlDisplayValue('color-select-dropdown-input', ['[data-testid*="color-select"]', '[data-testid*="colour-select"]']),
            packageSize: checkedPackageSize(),
            images: scrapeImages()
        };
        const fallback = extractPageMetadata();
        for (const key of ['title', 'description', 'price', 'brand']) details[key] ||= fallback[key];
        if (!details.images.length) details.images = fallback.images;
        console.log(`${LOG} [EDIT] scraped`, details);
        return details;
    }

    function mergeData(primary, fallback) {
        const merged = { ...fallback, ...primary };
        for (const key of ['title', 'description', 'price', 'category', 'brand', 'size', 'condition', 'color', 'packageSize']) {
            merged[key] = normaliseText(primary?.[key]) || normaliseText(fallback?.[key]);
        }
        // JSON-LD/OG images from the public item page are much safer than broad
        // DOM scraping on the edit page, which can accidentally capture UI assets.
        merged.images = fallback?.images?.length ? fallback.images : (primary?.images || []);
        return merged;
    }

    function meaningfulData(data) {
        return Boolean(normaliseText(data?.title) && normaliseText(data?.price));
    }

    // Set a value on a React-controlled input using the native prototype setter
    // (so React's value tracker sees the change) and dispatch the minimal event
    // pair React needs. No blur / duplicate InputEvent — extra synthetic events
    // are what tend to upset Vinted's controlled components.
    function setNativeValue(element, value) {
        if (!element) return false;
        const text = String(value ?? '');
        const proto = element instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
        const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
        try { setter ? setter.call(element, text) : (element.value = text); }
        catch (_) { element.value = text; }
        element.dispatchEvent(new Event('input', { bubbles: true }));
        element.dispatchEvent(new Event('change', { bubbles: true }));
        return element.value === text;
    }

    function cleanPrice(value) {
        let text = normaliseText(value).replace(/[^0-9.,]/g, '');
        if (!text) return '';
        const lastComma = text.lastIndexOf(',');
        const lastDot = text.lastIndexOf('.');
        if (lastComma > lastDot) text = text.replace(/\./g, '').replace(',', '.');
        else text = text.replace(/,/g, '');
        const parts = text.split('.');
        if (parts.length > 2) {
            const last = parts.at(-1);
            // Two-digit trailing group => decimal cents; otherwise the dots were
            // thousands separators and there are no decimals.
            text = last.length === 2 ? `${parts.slice(0, -1).join('')}.${last}` : parts.join('');
        }
        return text;
    }

    async function clickControl(testId, extraSelectors = []) {
        const selectors = [`[data-testid="${testId}"]`, ...extraSelectors];
        for (const selector of selectors) {
            const el = await waitForAny([selector], 5000);
            if (!el) continue;
            const clickable = el.closest('button, [role="button"], [data-testid$="--cell"]') || el;
            clickable.scrollIntoView({ block: 'center' });
            clickable.click();
            return true;
        }
        return false;
    }

    function activeOverlay() {
        const candidates = Array.from(document.querySelectorAll('[role="dialog"], [role="listbox"], [data-testid*="modal"], [data-testid*="dialog"], [class*="Dialog"], [class*="Modal"]'));
        return candidates.filter(visible).at(-1) || document.body;
    }

    async function selectVintedDropdown(testId, value, extraSelectors = []) {
        if (!normaliseText(value)) return true;
        const opened = await clickControl(testId, extraSelectors);
        if (!opened) {
            console.warn(`${LOG} dropdown control missing`, testId);
            return false;
        }
        await sleep(700);
        let overlay = activeOverlay();
        const search = Array.from(overlay.querySelectorAll('input[type="search"], input[type="text"], input:not([type])')).find(visible);
        if (search && search.getAttribute('data-testid') !== testId) {
            setNativeValue(search, value);
            await sleep(900);
            overlay = activeOverlay();
        }

        const desired = normaliseCompare(value);
        const candidates = Array.from(overlay.querySelectorAll(
            'button, [role="option"], [role="radio"], [role="menuitem"], label, [data-testid*="option"], [data-testid*="cell"]'
        )).filter(visible);
        let target = candidates.find(el => normaliseCompare(el.textContent) === desired);
        target ||= candidates.find(el => {
            const text = normaliseCompare(el.textContent);
            return text && (text.includes(desired) || desired.includes(text)) && Math.abs(text.length - desired.length) < 30;
        });
        if (!target) {
            console.warn(`${LOG} option not found`, { testId, value, candidates: candidates.slice(0, 15).map(x => normaliseText(x.textContent)) });
            document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
            return false;
        }
        target.scrollIntoView({ block: 'center' });
        target.click();
        await sleep(600);
        console.log(`${LOG} selected`, testId, value);
        return true;
    }

    function pageErrorText() {
        const nodes = Array.from(document.querySelectorAll('[role="alert"], [data-testid*="error"], [class*="error"], [class*="Error"]')).filter(visible);
        return normaliseText(nodes.map(node => node.textContent).join(' '));
    }

    // Fill only the text fields + dropdowns + package size. NO images here — image
    // upload is a separate, explicitly user-triggered stage. Runs only when the
    // user clicks "Fill saved details".
    async function fillDetails(data, onStatus = () => {}) {
        if (!meaningfulData(data)) return { ok: false, errors: ['Missing title or price'] };
        const errors = [];
        const title = await waitForAny(['input[data-testid="title--input"]', 'input[name="title"]'], 10000);
        const description = await waitForAny(['textarea[data-testid="description--input"]', 'textarea[name="description"]'], 10000);
        const price = await waitForAny(['input[data-testid="price-input--input"]', 'input[name="price"]'], 10000);
        const formattedPrice = cleanPrice(data.price);

        await runStage('text-fields', async () => {
            console.log(`${LOG} [NEW] field title <- "${data.title}"`);
            if (!title || !setNativeValue(title, data.title)) errors.push('title');
            onStatus('Filled: title');
            console.log(`${LOG} [NEW] field description (${(data.description || '').length} chars)`);
            if (description) setNativeValue(description, data.description || ''); else errors.push('description');
            onStatus('Filled: description');
            console.log(`${LOG} [NEW] field price <- "${formattedPrice}"`);
            if (!price || !setNativeValue(price, formattedPrice)) errors.push('price');
            onStatus('Filled: price');
        });

        const selections = [
            ['catalog-select-dropdown-input', data.category, ['[data-testid*="catalog-select"]']],
            ['brand-select-dropdown-input', data.brand, ['[data-testid*="brand-select"]']],
            ['category-size-single-grid-input', data.size, ['[data-testid*="size-single"]', '[data-testid*="size-select"]']],
            ['category-condition-single-list-input', data.condition, ['[data-testid*="condition-single"]', '[data-testid*="condition-select"]']],
            ['color-select-dropdown-input', data.color, ['[data-testid*="color-select"]', '[data-testid*="colour-select"]']]
        ];
        for (const [testId, value, selectors] of selections) {
            if (!value) continue;
            if (autofillState?.stopRequested) { console.log(`${LOG} [NEW] Safe stop honoured before dropdown ${testId}`); break; }
            console.log(`${LOG} [NEW] dropdown ${testId} <- "${value}"`);
            onStatus(`Selecting ${testId.replace(/-select.*$/, '')}…`);
            const stage = await runStage(`dropdown:${testId}`, () => selectVintedDropdown(testId, value, selectors));
            if (!stage.ok || stage.value === false) errors.push(testId);
        }

        if (data.packageSize) {
            console.log(`${LOG} [NEW] package size <- "${data.packageSize}"`);
            const stage = await runStage('package-size', async () => {
                const desired = normaliseCompare(data.packageSize);
                const cells = Array.from(document.querySelectorAll('[data-testid$="-package-size--cell"], div[id^="package-size-"], label')).filter(visible);
                const cell = cells.find(x => normaliseCompare(x.textContent).includes(desired));
                const radio = cell?.querySelector('input[type="radio"]');
                if (radio) radio.click(); else return false;
                return true;
            });
            if (!stage.ok || stage.value === false) errors.push('packageSize');
        }

        const pageError = pageErrorText();
        if (pageError) {
            console.error(`${LOG} [NEW] Vinted error text present after filling details`, pageError);
            errors.push('vintedPageError');
        }
        const coreOkay = Boolean(normaliseText(title?.value)) && cleanPrice(price?.value) === formattedPrice;
        return { ok: coreOkay && errors.length === 0, coreOkay, errors };
    }

    async function findAndClickDelete() {
        const end = Date.now() + 10000;
        while (Date.now() < end) {
            const candidates = Array.from(document.querySelectorAll('button, a, [role="button"]')).filter(visible);
            const button = candidates.find(el => /^(delete|remove listing|delete item)$/i.test(normaliseText(el.textContent))) ||
                candidates.find(el => /delete|remove listing/i.test(normaliseText(el.textContent)));
            if (button) { button.click(); return true; }
            await sleep(400);
        }
        return false;
    }

    async function confirmDelete() {
        const end = Date.now() + 10000;
        while (Date.now() < end) {
            const overlay = activeOverlay();
            const candidates = Array.from(overlay.querySelectorAll('button, [role="button"]')).filter(visible);
            const button = candidates.find(el => /^(delete|yes,? delete|confirm|remove)$/i.test(normaliseText(el.textContent))) ||
                candidates.find(el => /delete|remove/i.test(normaliseText(el.textContent)));
            if (button) { button.click(); return true; }
            await sleep(400);
        }
        return false;
    }

    // Explicitly leave the current route before a full-page navigation: mark the
    // phase, tear down observers/timers/pending stages, and log it. After this no
    // stale callback from this route can run (they all check isCurrent(gen), and
    // the generation is bumped on the next route). Only the item/edit flow may
    // navigate; the /items/new handler never calls this.
    function beginNavigation(reason) {
        phase = 'navigating';
        teardownRoute(reason);
    }

    async function processItemPage(gen) {
        const itemId = getItemId();
        const relistId = getRelistId();
        const path = location.pathname;
        const isEdit = /\/items\/\d+\/edit\/?$/.test(path);
        const isNew = /\/items\/new\/?$/.test(path);
        const isItem = Boolean(itemId && !isEdit && !isNew);

        if (isEdit && itemId) {
            console.log(`${LOG} [EDIT] ${itemId} gen=${gen}`);
            // The edit page is only entered as part of an explicit run. Without an
            // active, non-settled, non-stale transaction we do NOTHING here (no
            // scrape, no redirect) so a user browsing edit pages is never hijacked.
            const tx = await getTransaction(itemId);
            if (!isCurrent(gen)) return;
            if (!tx) { console.log(`${LOG} [EDIT] no active run for ${itemId}; edit handler idle`); return; }
            if (transactionSettled(tx)) {
                console.log(`${LOG} [EDIT] run already settled for ${itemId}; not re-scraping/redirecting`);
                renderPausedPanel(itemId, tx, 'This relist has already progressed past this step. Nothing was changed. Use Resume manually or Clear run.');
                return;
            }
            if (isStaleTransaction(tx)) {
                console.log(`${LOG} [EDIT] stale run for ${itemId}; not auto-continuing`);
                renderPausedPanel(itemId, tx, 'A previous relist run for this item is stale. Nothing was changed. Use Resume manually or Clear run.');
                return;
            }
            await setTransaction(itemId, { stage: 'scraping' });
            await waitForFormToLoad();
            if (!isCurrent(gen)) { console.warn(`${LOG} [ROUTE] stale callback ignored: edit scrape after route change (gen ${gen} != ${generation})`); return; }
            const scraped = await scrapeItemDetails();
            const partialKey = `pendingUpload_partial_${itemId}`;
            const fullKey = `pendingUpload_${itemId}`;
            const existing = await storageGet([partialKey]);
            const merged = mergeData(scraped, existing[partialKey] || {});
            if (!meaningfulData(merged)) {
                console.error(`${LOG} [EDIT] aborting: required data missing`, merged);
                return;
            }
            await storageSet({ [fullKey]: merged });
            await storageRemove([partialKey]);
            if (!isCurrent(gen)) { console.warn(`${LOG} [ROUTE] stale callback ignored: edit navigation suppressed (gen ${gen} != ${generation})`); return; }
            beginNavigation('pre-navigation edit -> item');
            location.assign(itemBaseUrl(itemId));
            return;
        }

        if (isItem) {
            // Loop prevention: the item handler runs the irreversible flow ONLY
            // for an explicit, active, non-settled, non-stale run. If Vinted
            // redirects back to this page after the delete / after /items/new, the
            // transaction is settled and we take NO action — this is the exact
            // loop from the video (re-download + re-delete) that we must not do.
            const tx = await getTransaction(itemId);
            if (!isCurrent(gen)) { console.warn(`${LOG} [ROUTE] stale callback ignored: item tx read after route change (gen ${gen} != ${generation})`); return; }
            if (!tx) {
                console.log(`${LOG} [ITEM] no active run for ${itemId}; item handler idle (no download/delete/redirect)`);
                return;
            }
            if (transactionSettled(tx)) {
                console.log(`${LOG} [ITEM] run already settled for ${itemId} (deletionAttempted=${Boolean(tx.deletionAttempted)} reachedNewPage=${Boolean(tx.reachedNewPage)} failed=${Boolean(tx.failed)}); NO re-download/re-delete/redirect`);
                renderPausedPanel(itemId, tx, tx.reachedNewPage
                    ? 'This item was already relisted to a new draft (photos are saved locally). Nothing was downloaded or deleted again.'
                    : 'This relist run already attempted deletion. Nothing was downloaded or deleted again. Use Resume manually or Clear run.');
                return;
            }
            if (isStaleTransaction(tx)) {
                console.log(`${LOG} [ITEM] stale run for ${itemId}; NOT auto-deleting`);
                renderPausedPanel(itemId, tx, 'A previous relist run for this item is stale. Nothing was downloaded or deleted. Use Resume manually or Clear run.');
                return;
            }

            const fullKey = `pendingUpload_${itemId}`;
            const partialKey = `pendingUpload_partial_${itemId}`;
            const saved = (await storageGet([fullKey]))[fullKey];
            if (!isCurrent(gen)) { console.warn(`${LOG} [ROUTE] stale callback ignored: item read after route change (gen ${gen} != ${generation})`); return; }
            if (!meaningfulData(saved)) {
                const partial = extractPageMetadata();
                if (partial.title || partial.price) await storageSet({ [partialKey]: partial });
                if (!isCurrent(gen)) return;
                beginNavigation('pre-navigation item -> edit');
                location.assign(editUrl(itemId));
                return;
            }

            // Safety gate 1: never delete the irreversible source listing unless we
            // have captured at least one image URL to rebuild the relist from.
            if (!Array.isArray(saved.images) || saved.images.length === 0) {
                console.error(`${LOG} [ITEM] refusing to delete ${itemId}: no images captured; source preserved`);
                showItemBanner('No images captured — source listing was NOT deleted.', true);
                return;
            }

            // Safety gate 2: before the irreversible delete, PRESERVE every image
            // to local Downloads. We only proceed to delete when ALL images are
            // confirmed downloaded (savedCount === total). A stored imagesSaved
            // flag lets a retry skip the download, but the flag alone never
            // authorises deletion — we re-verify the count each run and re-download
            // if a prior attempt was incomplete. On any failure we abort the
            // delete, show a visible error, and leave saved storage untouched.
            const savedFlagKey = `imagesSaved_${itemId}`;
            const totalImages = saved.images.length;
            const folder = `${itemId} ${normaliseText(saved.title)}`;
            const priorFlag = (await storageGet([savedFlagKey]))[savedFlagKey];
            if (!isCurrent(gen)) return;
            const alreadyComplete = priorFlag && priorFlag.savedCount === totalImages && priorFlag.total === totalImages;

            if (alreadyComplete) {
                console.log(`${LOG} [ITEM] images already preserved for ${itemId} (${totalImages}/${totalImages}); skipping re-download`);
                showItemBanner(`Photos already saved (${totalImages}/${totalImages}). Continuing…`);
            } else {
                console.log(`${LOG} [ITEM] preserving ${totalImages} image(s) for ${itemId} into "Vinted Relist/${folder}/" before delete`);
                showItemBanner(`Saving ${totalImages} photo(s) to Downloads/Vinted Relist before deleting…`);
                const result = await preserveImages(saved.images, folder);
                if (!isCurrent(gen)) { console.warn(`${LOG} [ROUTE] stale callback ignored: preserve result after route change (gen ${gen} != ${generation})`); return; }
                console.log(`${LOG} [ITEM] preserve result`, result);
                if (!result || result.ok !== true || result.savedCount !== totalImages) {
                    const got = result?.savedCount ?? 0;
                    console.error(`${LOG} [ITEM] image preservation incomplete for ${itemId}: ${got}/${totalImages} saved; DELETE ABORTED, storage retained`);
                    showItemBanner(`Only ${got}/${totalImages} photo(s) saved — DELETE ABORTED. Reload the item page to retry; nothing was deleted.`, true);
                    return;
                }
                await storageSet({ [savedFlagKey]: { savedCount: result.savedCount, total: totalImages, folder: result.folder, at: Date.now() } });
                console.log(`${LOG} [ITEM] all ${totalImages} image(s) preserved for ${itemId}; delete authorised`);
                showItemBanner(`All ${totalImages} photo(s) saved to Downloads/Vinted Relist/${result.folder}. Deleting source listing…`);
            }

            // Idempotency: persist deletionAttempted BEFORE clicking delete. If
            // Vinted errors and bounces back to this page, transactionSettled(tx)
            // is now true, so the item handler will refuse to download or delete
            // again (it shows the paused panel instead).
            await setTransaction(itemId, { stage: 'deleting', downloadConfirmed: true, deletionAttempted: true });
            if (!isCurrent(gen)) return;
            console.log(`${LOG} [ITEM] deleting source item ${itemId} (${totalImages} image(s) preserved locally)`);
            if (!(await findAndClickDelete())) {
                console.error(`${LOG} [ITEM] delete action not found; source was NOT deleted`);
                return;
            }
            if (!(await confirmDelete())) {
                console.error(`${LOG} [ITEM] delete confirmation not found; source may not be deleted`);
                return;
            }
            await sleep(1200);
            if (!isCurrent(gen)) return;
            beginNavigation('pre-navigation item -> new');
            location.assign(newItemUrl(itemId));
            return;
        }

        if (isNew && relistId) {
            await handleNewPage(gen, relistId);
        }
    }

    // /items/new handler. Waits for app/form stability, then renders the status
    // panel and fills ONLY the text fields + dropdowns. It NEVER redirects, NEVER
    // touches the file input, and NEVER publishes: it stops at the reviewable
    // populated state and tells the user where the photos were saved so they can
    // pick them manually. Saved data + run state persist through errors and are
    // cleared only by the user (Clear data / Clear run).
    async function handleNewPage(gen, relistId) {
        console.log(`${LOG} [NEW] start relist=${relistId} gen=${gen}`, location.href);
        watchPageHealth(gen);

        // Mark the run as having reached /items/new. This is a point of no return
        // for the SOURCE item handler: if Vinted's error boundary bounces us back
        // to the (now-deleted) item page, transactionSettled(tx) is true and the
        // item handler will NOT download or delete again.
        await setTransaction(relistId, { stage: 'reachedNew', reachedNewPage: true });
        if (!isCurrent(gen)) return;

        const fullKey = `pendingUpload_${relistId}`;
        let saved;
        try {
            saved = (await storageGet([fullKey]))[fullKey];
        } catch (error) {
            console.error(`${LOG} [NEW] storage-read threw:`, error?.message, '\n', error?.stack || error);
            return;
        }
        if (!isCurrent(gen)) return;
        if (!meaningfulData(saved)) {
            console.error(`${LOG} [NEW] no valid saved data for ${relistId}; autofill not started`);
            return;
        }

        // Where did the source photos get saved? Read the imagesSaved flag so the
        // panel can tell the user the exact folder + count to pick manually.
        let photoInfo = null;
        try {
            const flag = (await storageGet([`imagesSaved_${relistId}`]))[`imagesSaved_${relistId}`];
            if (flag && flag.folder) photoInfo = { folder: flag.folder, count: flag.savedCount ?? flag.total ?? (saved.images?.length || 0) };
        } catch (_) { /* best-effort */ }
        if (!photoInfo) photoInfo = { folder: `${relistId} ${normaliseText(saved.title)}`, count: saved.images?.length || 0 };
        if (!isCurrent(gen)) return;

        await runStage('app-ready', waitForAppReady);
        if (!isCurrent(gen)) { console.warn(`${LOG} [ROUTE] stale callback ignored: app-ready resolved after route change (gen ${gen} != ${generation})`); return; }
        await waitForNewFormToRender();
        if (!isCurrent(gen)) { console.warn(`${LOG} [ROUTE] stale callback ignored: form-render resolved after route change (gen ${gen} != ${generation})`); return; }

        const panel = renderAutofillPanel(gen, relistId, saved, fullKey, photoInfo);
        autofillState = {
            gen, saved, fullKey,
            stageIndex: 0, running: false, stopRequested: false,
            setStatus: panel ? panel.setStatus : (() => {}),
            buttons: panel ? panel.buttons : null
        };
        console.log(`${LOG} [NEW] app ready; starting staged autofill (no auto-publish)`);
        runAutofill(gen, 0);
    }

    function showSelectionDialog(items) {
        const overlay = document.createElement('div');
        overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:2147483647;display:flex;justify-content:center;align-items:center';
        const dialog = document.createElement('div');
        dialog.style.cssText = 'background:#fff;color:#111;padding:20px;border-radius:10px;width:min(520px,90vw);max-height:80vh;display:flex;flex-direction:column';
        const heading = document.createElement('h3');
        heading.textContent = 'Select Items to Relist';
        dialog.appendChild(heading);
        const list = document.createElement('div');
        list.style.cssText = 'overflow:auto;margin-bottom:15px;border:1px solid #ccc;padding:10px';
        items.forEach((item, index) => {
            const row = document.createElement('label');
            row.style.cssText = 'display:block;padding:5px';
            const box = document.createElement('input');
            box.type = 'checkbox';
            box.value = item.link;
            box.dataset.itemId = item.id;
            row.append(box, document.createTextNode(` ${item.title}`));
            list.appendChild(row);
        });
        const start = document.createElement('button');
        start.textContent = 'Start Selected';
        start.style.cssText = 'padding:15px;background:#09b1ba;color:#fff;border:0;border-radius:5px;font-weight:bold';
        // A relist run starts ONLY here, on an explicit user click. For each
        // selected item we write a fresh transaction (unique runId) keyed on the
        // source id BEFORE opening its page — this is the single authorised entry
        // point. Route handlers never start a run on their own.
        start.onclick = async () => {
            const selected = Array.from(list.querySelectorAll('input:checked'));
            overlay.remove();
            for (let index = 0; index < selected.length; index++) {
                const box = selected[index];
                const id = box.dataset.itemId;
                const url = box.value;
                try {
                    await setTransaction(id, {
                        runId: makeRunId(),
                        stage: 'started',
                        sourceUrl: url,
                        startedAt: Date.now(),
                        downloadConfirmed: false,
                        deletionAttempted: false,
                        reachedNewPage: false,
                        failed: false
                    });
                    console.log(`${LOG} [TX] run started for ${id}`);
                } catch (error) {
                    console.error(`${LOG} [TX] failed to start run for ${id}:`, error?.message);
                }
                setTimeout(() => window.open(url, '_blank', 'noopener'), index * 250);
            }
        };
        dialog.append(list, start);
        overlay.appendChild(dialog);
        document.body.appendChild(overlay);
    }

    function injectButton() {
        if (!document.body || document.getElementById('relist-btn')) return;
        const button = document.createElement('button');
        button.id = 'relist-btn';
        button.textContent = '▶ Mass Relist';
        button.style.cssText = 'position:fixed;top:80px;right:20px;z-index:2147483646;padding:15px;background:#09b1ba;color:#fff;border:0;border-radius:5px;cursor:pointer;font-size:16px;font-weight:bold;box-shadow:0 4px 6px rgba(0,0,0,.3)';
        button.onclick = () => {
            const links = Array.from(document.querySelectorAll('a[href*="/items/"]'));
            const seen = new Set();
            const items = links.map(link => {
                const href = link.href;
                const id = href.match(/\/items\/(\d+)/)?.[1];
                if (!id || seen.has(id) || /\/edit/.test(href)) return null;
                seen.add(id);
                return { id, title: normaliseText(link.title || link.getAttribute('aria-label') || link.textContent) || `Item ${id}`, link: itemBaseUrl(id) };
            }).filter(Boolean);
            if (items.length) showSelectionDialog(items); else alert('No item links found on this page.');
        };
        document.body.appendChild(button);
    }

    // Boot: install the SPA route monitor (history patch + popstate/hashchange +
    // 1s fallback poll), then classify the current route once. Every subsequent
    // client-side navigation flows through onRouteChange, which tears the old
    // route down (bumping the generation so stale callbacks abort) and starts a
    // single handler for the new route via dispatchRoute.
    installRouteMonitor();
    onRouteChange(location.pathname);
})();
